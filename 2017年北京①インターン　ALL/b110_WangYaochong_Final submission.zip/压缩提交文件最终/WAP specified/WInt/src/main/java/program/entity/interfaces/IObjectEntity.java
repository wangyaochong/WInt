package program.entity.interfaces;

/**
 * Created by【王耀冲】on 【2017/6/30】 at 【18:07】.
 */
public interface IObjectEntity {
    void setTitle(String title);
    String getTitle();
    void setDescription(String description);
    String getDescription();
    void setType(String type);
    String getType();
}
