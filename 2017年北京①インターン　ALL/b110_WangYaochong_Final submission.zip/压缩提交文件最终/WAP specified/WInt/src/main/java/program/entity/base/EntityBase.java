package program.entity.base;

public class EntityBase {
}
