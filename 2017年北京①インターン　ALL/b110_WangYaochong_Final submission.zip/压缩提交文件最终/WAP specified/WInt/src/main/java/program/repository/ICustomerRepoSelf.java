package program.repository;

public interface ICustomerRepoSelf<T,ID>{
    T testAdd();
}
