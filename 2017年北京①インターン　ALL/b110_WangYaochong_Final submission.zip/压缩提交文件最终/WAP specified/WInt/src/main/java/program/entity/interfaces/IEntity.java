package program.entity.interfaces;

/**
 * Created by【王耀冲】on 【2016/12/25】 at 【19:11】.
 */
public interface IEntity {//只是用来泛化，没有实际作用
    void setId(String id);
    String getId();
}
