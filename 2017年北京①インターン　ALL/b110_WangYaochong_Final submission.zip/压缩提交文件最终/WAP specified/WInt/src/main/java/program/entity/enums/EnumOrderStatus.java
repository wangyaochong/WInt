package program.entity.enums;

public enum EnumOrderStatus {
    COOKING,
    COOKED,
    DELIVERING,
    DELIVERED
}
