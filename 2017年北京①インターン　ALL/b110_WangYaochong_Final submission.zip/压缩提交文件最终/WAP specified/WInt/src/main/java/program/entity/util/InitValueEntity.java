package program.entity.util;

/**
 * Created by【王耀冲】on 【2017/6/27】 at 【12:07】.
 */
public class InitValueEntity {
    String initString="qazwsxedcrfvtgbyhnujmik,ol.p;/[']-0987654321`";
    Integer initInteger=Integer.MIN_VALUE;
    Double initDouble=Double.MIN_VALUE;
    Float initFloat=Float.MIN_VALUE;
}
