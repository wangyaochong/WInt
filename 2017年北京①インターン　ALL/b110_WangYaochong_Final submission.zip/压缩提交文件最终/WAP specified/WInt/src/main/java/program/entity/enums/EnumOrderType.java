package program.entity.enums;

public enum EnumOrderType {
    ONLINE,
    STORE,
    SYSTEM_FOR_PREPARATION
}
