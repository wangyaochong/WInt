package test;

import org.apache.commons.lang3.RandomUtils;
import org.junit.Test;

public class TestRandom {
    @Test
    public void test(){
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
        System.out.println(RandomUtils.nextInt(0, 5));
    }
}
