package program.entity.enums;

public enum EnumGender {
    MALE,
    FEMALE
}
